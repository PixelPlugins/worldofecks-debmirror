int main(){
	printf("Hello, world!");
}